# TODOs LIST
> Proyecto entregable del segundo modulo del diplomado "Despliegue de Modelos de Machine Learning"


## Installation

OS X & Linux & Windows:

```sh
pip install 
```

## Usage example

If you want to run a funtions in todos.py
```sh
python todos.py
```


## Test

If you want to check te test
 
```sh
One by One pythe

General
```

## Meta

Valeria Hernandez – [@YourTwitter](https://twitter.com/dbader_org) – YourEmail@example.com

Distributed under the XYZ license. See ``LICENSE`` for more information.

[https://github.com/yourname/github-link](https://github.com/dbader/)


