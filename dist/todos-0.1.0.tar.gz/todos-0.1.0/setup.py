# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['todos', 'todos.src', 'todos.tests.integracion', 'todos.tests.unit']

package_data = \
{'': ['*'], 'todos': ['data/*']}

setup_kwargs = {
    'name': 'todos',
    'version': '0.1.0',
    'description': 'Entrega del modulo II. Creacion de un to_do list.',
    'long_description': '# TODOs LIST\n> Proyecto entregable del segundo modulo del diplomado "Despliegue de Modelos de Machine Learning"\n\n\n## Installation\n\nOS X & Linux & Windows:\n\n```sh\npip install \n```\n\n## Usage example\n\nIf you want to run a funtions in todos.py\n```sh\npython todos.py\n```\n\n\n## Test\n\nIf you want to check te test\n \n```sh\nOne by One pythe\n\nGeneral\n```\n\n## Meta\n\nValeria Hernandez – [@YourTwitter](https://twitter.com/dbader_org) – YourEmail@example.com\n\nDistributed under the XYZ license. See ``LICENSE`` for more information.\n\n[https://github.com/yourname/github-link](https://github.com/dbader/)\n\n\n',
    'author': 'Valeria Hernandez',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
